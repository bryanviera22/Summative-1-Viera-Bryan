package com.company.Summative1VieraBryan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Summative1VieraBryanApplication {

	public static void main(String[] args) {
		SpringApplication.run(Summative1VieraBryanApplication.class, args);
	}

}
