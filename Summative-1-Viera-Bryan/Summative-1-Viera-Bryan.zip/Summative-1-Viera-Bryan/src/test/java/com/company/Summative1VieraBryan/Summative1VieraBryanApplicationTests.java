package com.company.Summative1VieraBryan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Summative1VieraBryanApplicationTests {

	@Test
	void contextLoads() {
	}

}
